<?php $__env->startSection('content'); ?>
    <div class="container">

        <h2 class="font-weight-bold">Add Your Venture</h2>
        <!-- Add Your Venture Box -->
        <div class="alert alert-info p-4 mb-4">
            <p>With a venture profile you can:</p>
            <ul>
                <li>Build a following and promote your venture to a global network</li>
                <li>Connect to fellow founders, mentors, and investors</li>
                <li>Be found by support program organizers</li>
                <li>Apply to select program opportunities for support</li>
                <li>Apply for mentorship</li>
                <li>Start free courses on the Startup Academy</li>
                <li>Document your progress and launch a fundraising campaign</li>
            </ul>
            <p>Creating a venture profile is simple and only takes 5 minutes. Provide basic information about your company
                and enrich the profile with additional information after publishing the page. Take a moment to review our
                guidelines to be sure your venture is a good fit.</p>
        </div>

        <!-- Venture Details Form -->
        <form action="<?php echo e(route('submit.venture')); ?>" method="POST"> <?php echo csrf_field(); ?>
            <h4 class="font-weight-bold mb-3">Venture Details</h4>

            <!-- Company Name -->
            <div class="form-group">
                <label for="company_name">Company Name</label>
                <input type="text" class="form-control" id="company_name" name="company_name" required>
            </div>

            <!-- Tagline -->
            <div class="form-group">
                <label for="tagline">Tagline</label>
                <input type="text" class="form-control" id="tagline" name="tagline" required>
            </div>

            <!-- Founding Date -->
            <div class="form-group">
                <label for="founding_date">Founding Date</label>
                <input type="date" class="form-control" id="founding_date" name="founding_date" required>
            </div>

            <!-- Pitch -->
            <div class="form-group">
                <label for="pitch">Pitch</label>
                <textarea class="form-control" id="pitch" name="pitch" rows="4" required></textarea>
            </div>

            <!-- Pitch Video URL -->
            <div class="form-group">
                <label for="pitch_video_url">Pitch Video URL</label>
                <input type="url" class="form-control" id="pitch_video_url" name="pitch_video_url" required>
            </div>

            <!-- Full Address -->
            <div class="form-group">
                <label for="full_address">Full Address</label>
                <input type="text" class="form-control" id="full_address" name="full_address" required>
            </div>

            <!-- Phone Number (Optional) -->
            <div class="form-group">
                <label for="phone_no">Phone Number (Optional)</label>
                <input type="tel" class="form-control" id="phone_no" name="phone_no">
            </div>

            <!-- Stage -->
            <div class="form-group">
                <label>Stage</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="stage" id="idea_stage" value="Idea/Concept stage"
                        required>
                    <label class="form-check-label" for="idea_stage">Idea/Concept stage</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="stage" id="startup_stage" value="Startup stage">
                    <label class="form-check-label" for="startup_stage">Startup stage</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="stage" id="growth_stage" value="Growth stage">
                    <label class="form-check-label" for="growth_stage">Growth stage</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="stage" id="mature_stage" value="Mature stage">
                    <label class="form-check-label" for="mature_stage">Mature stage</label>
                </div>
            </div>

            <!-- Customer Type -->
            <div class="form-group">
                <label>What type of customers do you serve?</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="B2B">
                    <label class="form-check-label" for="b2b">B2B</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="B2B2B">
                    <label class="form-check-label" for="b2b2b">B2B2B</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="B2B2C">
                    <label class="form-check-label" for="b2b2c">B2B2C</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="B2C">
                    <label class="form-check-label" for="b2c">B2C</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="C2C">
                    <label class="form-check-label" for="c2c">C2C</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="B2G">
                    <label class="form-check-label" for="b2g">Governments (B2G)</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customers[]" value="Non-profits">
                    <label class="form-check-label" for="nonprofits">Non-profits</label>
                </div>
            </div>

            <!-- Customer Base -->
            <div class="form-group">
                <label>Where are your customers based?</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customer_base[]" value="Urban">
                    <label class="form-check-label" for="urban">Urban based customers</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="customer_base[]" value="Rural">
                    <label class="form-check-label" for="rural">Rural based customers</label>
                </div>
            </div>

            <!-- Sectors -->
            <div class="form-group">
                <label for="sectors">Sectors</label>
                <select class="form-control" id="sectors" name="sectors[]" multiple>
                    <option value="Tech">Technology</option>
                    <option value="Health">Healthcare</option>
                    <option value="Finance">Finance</option>
                    <option value="Education">Education</option>
                </select>
            </div>

            <!-- Countries -->
            <div class="form-group">
                <label for="countries">Countries</label>
                <select class="form-control" id="countries" name="countries[]" multiple>
                    <option value="US">United States</option>
                    <option value="IN">India</option>
                    <option value="GB">United Kingdom</option>
                    <option value="DE">Germany</option>
                </select>
            </div>

            <!-- Online Presence -->
            <h4 class="font-weight-bold mb-3">Online Presence</h4>

            <!-- Website -->
            <div class="form-group">
                <label for="website">Website</label>
                <input type="url" class="form-control" id="website" name="website">
            </div>

            <!-- Social Media Links -->
            <div class="form-group">
                <label>Social Media</label><br>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fab fa-instagram"></i></span>
                    <input type="url" class="form-control" name="instagram" placeholder="Instagram Link">
                </div>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fab fa-facebook"></i></span>
                    <input type="url" class="form-control" name="facebook" placeholder="Facebook Link">
                </div>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fab fa-linkedin"></i></span>
                    <input type="url" class="form-control" name="linkedin" placeholder="LinkedIn Link">
                </div>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fab fa-twitter"></i></span>
                    <input type="url" class="form-control" name="twitter" placeholder="Twitter Link">
                </div>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fab fa-youtube"></i></span>
                    <input type="url" class="form-control" name="youtube" placeholder="YouTube Link">
                </div>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fab fa-tiktok"></i></span>
                    <input type="url" class="form-control" name="tiktok" placeholder="TikTok Link">
                </div>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary btn-block mt-4">Publish and View Venture Profile</button>
        </form>
    </div>
    <style>
        body {
            background: #f0f2f5;
            font-family: "Segoe UI", sans-serif;
        }

        .container {
            max-width: 900px;
            margin: 30px auto;
            padding: 40px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }

        h3,
        h4 {
            color: #222;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .alert-info {
            background: #e9f4ff;
            border-left: 5px solid #007bff;
            padding: 25px;
            border-radius: 6px;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
            color: #333;
        }

        .form-control {
            border: 1px solid #ccc;
            padding: 12px;
            border-radius: 6px;
            font-size: 14px;
            width: 100%;
            transition: border 0.3s ease;
        }

        .form-control:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 123, 255, .2);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-check {
            margin-right: 15px;
        }

        .form-check-label {
            font-weight: 400;
        }

        select[multiple] {
            min-height: 120px;
            background-color: #fff;
            cursor: pointer;
        }

        option {
            padding: 6px;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 12px;
            font-weight: 600;
            font-size: 16px;
            border-radius: 6px;
            width: 100%;
            margin-top: 25px;
            transition: background 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .input-group-text {
            background-color: #f0f0f0;
            border: 1px solid #ccc;
        }

        .input-group .form-control {
            border-left: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wave_old_version/evoting/resources/views/ventures.blade.php ENDPATH**/ ?>