<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Business;

class BusinessController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'company_name'      => 'required|string',
            'tagline'           => 'required|string',
            'founding_date'     => 'required|date',
            'pitch'             => 'required|string',
            'pitch_video_url'   => 'required|url',
            'full_address'      => 'required|string',
            'phone_no'          => 'nullable|string',
            'stage'             => 'required|string',
            'customers'         => 'nullable|array',
            'customer_base'     => 'nullable|array',
            'sectors'           => 'nullable|array',
            'countries'         => 'nullable|array',
            'website'           => 'nullable|url',
            'instagram'         => 'nullable|url',
            'facebook'          => 'nullable|url',
            'linkedin'          => 'nullable|url',
            'twitter'           => 'nullable|url',
            'youtube'           => 'nullable|url',
            'tiktok'            => 'nullable|url',
        ]);

        $business = new Business();
        $business->company_name     = $request->company_name;
        $business->tagline          = $request->tagline;
        $business->founding_date    = $request->founding_date;
        $business->pitch            = $request->pitch;
        $business->pitch_video_url  = $request->pitch_video_url;
        $business->full_address     = $request->full_address;
        $business->phone_number     = $request->phone_no;
        $business->stage            = $request->stage;

        // Join arrays into strings
        $business->what             = $request->customers ? implode(',', $request->customers) : null;
        $business->where            = $request->customer_base ? implode(',', $request->customer_base) : null;
        $business->sectors          = $request->sectors ? implode(',', $request->sectors) : null;
        $business->countries        = $request->countries ? implode(',', $request->countries) : null;

        $business->website          = $request->website;

        // Combine social media links into JSON
        $business->instagram = $request->instagram;
        $business->linkedin = $request->linkedin;
        $business->facebook = $request->facebook;
        $business->tiktok = $request->tiktok;
        $business->twitter = $request->twitter;
        $business->youtube = $request->youtube;


        $business->save();

        return redirect()->back()->with('success', 'Venture profile submitted successfully!');
    }
}
