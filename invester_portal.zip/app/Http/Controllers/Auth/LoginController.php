<?php

namespace App\Http\Controllers\Auth;

use Wave\Http\Controllers\Auth\LoginController as AuthLoginController;

class LoginController extends AuthLoginController
{

}
