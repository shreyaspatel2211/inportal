<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VentureController extends Controller
{
    // Show the form to create a venture
    public function create()
    {
        return view('ventures'); // Points to 'resources/views/ventures.blade.php'
    }

    // Store the submitted venture data
    public function store(Request $request)
    {
        // Handle form submission and validation here
        $validatedData = $request->validate([
            'company_name' => 'required|string|max:255',
            'tagline' => 'required|string|max:255',
            'founding_date' => 'required|date',
            'pitch' => 'required|string',
            'pitch_video_url' => 'nullable|url',
            'full_address' => 'required|string',
            'phone_no' => 'nullable|string',
            'stage' => 'required|string',
            'customers' => 'nullable|array',
            'customer_base' => 'nullable|array',
            'sectors' => 'nullable|array',
            'countries' => 'nullable|array',
            'website' => 'nullable|url',
            'instagram' => 'nullable|url',
            'facebook' => 'nullable|url',
            'linkedin' => 'nullable|url',
            'twitter' => 'nullable|url',
            'youtube' => 'nullable|url',
            'tiktok' => 'nullable|url',
        ]);

        // Optionally save the data to the database
        // Example: Venture::create($validatedData);

        // Redirect back to the form with a success message
        return redirect()->route('ventures.create')->with('status', 'Venture profile has been created!');
    }
}
