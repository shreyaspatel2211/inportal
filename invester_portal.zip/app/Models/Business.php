<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Business extends Model
{
    use HasFactory;
    protected $table = 'businesses'; // if your table name is `businesses`

    protected $fillable = [
        'company_name',
        'tagline',
        'founding_date',
        'pitch',
        'pitch_video_url',
        'full_address',
        'phone_number',
        'stage',
        'what',
        'where',
        'sectors',
        'countries',
        'website',
        'social_media'
    ];
}
